const mongoose = require('mongoose');
let adminSchema = mongoose.Schema({
   username:{
        type:String,
        required:true
    },
    email:{
        type:String,
        required:true
    },
    password:{
        type:String,
        required:true
    }
    

},{collection:'admin'});

let Admin = module.exports = mongoose.model('Admin',adminSchema);