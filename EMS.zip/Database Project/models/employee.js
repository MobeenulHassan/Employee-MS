const mongoose = require('mongoose');
let empSchema = mongoose.Schema({
    name:{
        type:String,
        required:true
    },
    surname:{
        type:String,
        required:true
    },
    job:{
        type:String,
        required:true
    },
    salary:{
        type:Number,
        required:true
    },
    department:{
        type:String,
        required:true
    }

},{collection:'employee'});

let Employee = module.exports = mongoose.model('Employee',empSchema);