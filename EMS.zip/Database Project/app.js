const express = require('express');
const path = require('path');
const mongoose = require('mongoose');
const app = express();
const port = 3001;
const bodyParser = require('body-parser');
const urlEncodedParser = bodyParser.urlencoded({extended:false});
app.use(bodyParser.json());


let Employee = require('./models/employee');
let Admin = require('./models/admin');
//DB Connection
mongoose.connect('mongodb://localhost/myapp');
let db = mongoose.connection;
//Check Connection
db.once('open',function(){
    console.log('Connected to Mongo DB');
})

//Check db Errors
db.on('error',function(err){
    console.log(err);
});


//Set views
app.set('views',path.join(__dirname,'views'));
app.set('view engine','pug');

//Handling Static files
app.use(express.static(path.join(__dirname,'public')));


//Index
app.get('/',function(req,res){
  
    res.render('index');
      
});

//Home Page
app.get('/home',function(req,res){
    Employee.find({},function(err,emp){
        if(err){
            console.log(err);
        }
        else{
            res.render('home',{
                emp:emp
            });
        }
    });
});

//Salary Filter
app.post('/FilterSalary', urlEncodedParser, function(req,res){

    Employee.find({salary: {$lte: req.body.salary}}, function(err,emp){
        if(err){
            console.log(err);
        }
        else{
            res.render('home',{
                emp:emp
            });
        }
    });
});


//Department Filter
app.post('/FilterDepartment', urlEncodedParser, function(req,res){

    Employee.find({department: req.body.department}, function(err,emp){
        if(err){
            console.log(err);
        }
        else{
            res.render('home',{
                emp:emp
            });
        }
    });
});

//Name Filter
app.post('/FilterName', urlEncodedParser, function(req,res){

    Employee.find({name: req.body.name}, function(err,emp){
        if(err){
            console.log(err);
        }
        else{
            res.render('home',{
                emp:emp
            });
        }
    });
});


// Show Login Page
app.get('/login',function(req,res){
    res.render('login');
});


// Login User
app.post('/login',urlEncodedParser, function(req,res){
    
    Admin.find({email: req.body.email , password: req.body.password}, function(err, result) {
        console.log(err);
        console.log(result);

        if (result && result.length == 1)
        {
            res.redirect('/home');
        }
        else {            
            res.redirect('/login');
            
        }
      });


});


//Show add new employee page
app.get('/add',function(req,res){
    res.render('add');
});

//Add new Employee
app.post('/add',urlEncodedParser,function(req,res){
    let employee = new Employee();
    employee.name = req.body.name;
    employee.surname = req.body.surname;
    employee.job = req.body.job;
    employee.salary = req.body.salary;
    employee.department = req.body.department;

    employee.save(function(err){
        if(err){
            console.log(err);
        }else{
            res.redirect('/home');
        }
    });
});


// show sign-up page
app.get('/signup',function(req,res){
    res.render('signup');
});

// Register user
app.post('/signup',urlEncodedParser,function(req,res){
    let admin = new Admin();
    admin.username = req.body.username;
    admin.email = req.body.email;
    admin.password = req.body.password;
    
    admin.save(function(err){
        if(err){
            console.log(err);
        }else{
            res.redirect('/home');
        }
    });
});

// Show Update Page 
app.get('/update',function(req,res){
    Employee.find({},function(err,emp){
        if(err){
            console.log(err);
        }
        else{
            res.render('update',{
                emp:emp
            });
        }
    });
    
});

//Show Edit page for selected employee
app.get('/update/edit/:id',function(req,res){
    Employee.findById(req.params.id,function(err,emp){
        if(err){
            console.log(err);
        }
        else{
            res.render('edit',{
                emp:emp
            });
        }
    });
});

//Edit Employee
app.post('/update/edit/:id',urlEncodedParser,function(req,res){
    let employee = {};
    employee.name = req.body.name;
    employee.surname = req.body.surname;
    employee.job = req.body.job;
    employee.salary = req.body.salary;
    employee.department = req.body.department;

    let query = {_id:req.params.id};
    Employee.updateOne(query,employee,function(err){
        if(err){
            console.log(err);
            return;
        }
        else{
            res.redirect('/home');
        }
    });
});





//Show Remove Employee Page
app.get('/remove',function(req,res){
    Employee.find({},function(err,emp){
        if(err){
            console.log(err);
        }
        else{
        res.render('remove',{
            emp:emp
        });
    }
    });
});

//Remove Employee
app.delete('/remove/:id',function(req,res){
    let query = {_id:req.params.id};
    Employee.deleteOne(query,function(err){
        if(err){
            console.log(err);
        }
        else{
            res.send();
        }
    });
});



//Creating Server
app.listen(port,function(){
    console.log(`App is running on port : ${port}`);
});